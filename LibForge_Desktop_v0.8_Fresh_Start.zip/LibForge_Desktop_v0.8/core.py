"""Coordinate-exact, toolkit-independent CAD model for LibForge Desktop.

All geometry is stored as integral nanometres. 1 mil == 25,400 nm.
Qt scene coordinates are *not* used for persistence or native exports.
"""
from __future__ import annotations

import copy
import json
import math
import uuid
from dataclasses import dataclass, asdict, field
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

NM_PER_MM = 1_000_000
NM_PER_MIL = 25_400


def unit_to_nm(value: str | float | int | Decimal, unit: str) -> int:
    factor = NM_PER_MIL if unit.lower() == "mil" else NM_PER_MM
    return int((Decimal(str(value)) * factor).to_integral_value(rounding=ROUND_HALF_UP))


def nm_to_unit(value: int, unit: str) -> float:
    return value / (NM_PER_MIL if unit == "mil" else NM_PER_MM)


def snap_1d(value: int, origin: int, pitch: int) -> int:
    """Half-up symmetric snap, including negative coordinates (no float drift)."""
    if pitch <= 0:
        raise ValueError("Snap grid must be positive")
    delta = value - origin
    if delta >= 0:
        return origin + ((2 * delta + pitch) // (2 * pitch)) * pitch
    return origin - ((2 * (-delta) + pitch) // (2 * pitch)) * pitch


@dataclass
class Grid:
    unit: str = "mil"
    snapX: int = 2_540_000
    snapY: int = 2_540_000
    visibleX: int = 2_540_000
    visibleY: int = 2_540_000
    originX: int = 0
    originY: int = 0
    coarse: int = 5
    style: str = "dots"  # dots, lines, hidden
    snapEnabled: bool = True
    showGrid: bool = True
    strictGrid: bool = True
    objectSnap: bool = True
    hotspotRange: int = 1_270_000  # UI maps to a bounded pixel radius
    electricalEnabled: bool = True
    electricalRange: int = 1_270_000

    def snap(self, p: tuple[int, int]) -> tuple[int, int]:
        if not self.snapEnabled:
            return tuple(map(int, p))
        return (snap_1d(p[0], self.originX, self.snapX),
                snap_1d(p[1], self.originY, self.snapY))

    @classmethod
    def from_mapping(cls, obj: dict | None, pcb: bool = False) -> "Grid":
        base = cls.pcb() if pcb else cls()
        if not isinstance(obj, dict):
            return base
        for k in asdict(base):
            if k in obj:
                setattr(base, k, obj[k])
        base.snapX = max(1, int(base.snapX))
        base.snapY = max(1, int(base.snapY))
        base.visibleX = max(1, int(base.visibleX))
        base.visibleY = max(1, int(base.visibleY))
        base.coarse = max(1, int(base.coarse))
        return base

    @classmethod
    def pcb(cls) -> "Grid":
        return cls(unit="mm", snapX=50_000, snapY=50_000,
                   visibleX=500_000, visibleY=500_000,
                   hotspotRange=150_000, electricalRange=150_000,
                   electricalEnabled=False, style="lines")


def make_id() -> str:
    return "lf_" + uuid.uuid4().hex[:10]


def empty_project() -> dict:
    """Start with an empty project. No legacy import or migration."""
    return {
        "format": "LibForgeDesktop", "version": 8,
        "components": [], "footprints": [],
        "categories": {"components": ["IC/Opamp", "IC/MCU", "Passive", "Connector"],
                       "footprints": ["SMD/QFN", "SMD/SOIC", "SMD/QFP", "THT"]},
        "active": None, "activeFootprint": None,
    }



def normalize_project(src: dict) -> dict:
    """Strict v0.8 only. Legacy files are deliberately not migrated."""
    if not isinstance(src,dict) or src.get("format")!="LibForgeDesktop" or src.get("version")!=8:
        raise ValueError("LibForge v0.8 JSON projesi gerekiyor")
    out=copy.deepcopy(src)
    if not isinstance(out.get("components"),list) or not isinstance(out.get("footprints"),list):
        raise ValueError("Komponent / footprint listesi geçersiz")
    if not isinstance(out.get("categories"),dict):
        raise ValueError("Kategori yapısı geçersiz")
    for mode,records in (("sch",out["components"]),("pcb",out["footprints"])):
        used=set()
        for rec in records:
            if not isinstance(rec,dict) or not str(rec.get("name","")).strip():
                raise ValueError("Bilinmeyen komponent/footprint adı")
            rec.setdefault("id",make_id())
            if rec["id"] in used:raise ValueError("Tekrarlanan kayıt kimliği")
            used.add(rec["id"])
            field="symbol" if mode=="sch" else "pcb"
            if not isinstance(rec.get(field),list):raise ValueError(f"{rec['name']}: geçersiz geometri")
            rec.setdefault("category","IC/Other" if mode=="sch" else "SMD/Other")
            rec["grid"]=asdict(Grid.from_mapping(rec.get("grid"),pcb=mode=="pcb"))
    return out


def load_project(path:Path|str)->dict:
    return normalize_project(json.loads(Path(path).read_text(encoding="utf-8-sig")))


def save_project(path:Path|str,project:dict)->None:
    Path(path).write_text(json.dumps(normalize_project(project),ensure_ascii=False,indent=2),encoding="utf-8")


def point_to_segment_projection(p: tuple[int,int], a: tuple[int,int], b: tuple[int,int]) -> tuple[tuple[int,int],float]:
    dx=b[0]-a[0];dy=b[1]-a[1]
    len2=dx*dx+dy*dy
    if len2==0:
        return a, math.hypot(p[0]-a[0],p[1]-a[1])
    t=max(0.,min(1., ((p[0]-a[0])*dx+(p[1]-a[1])*dy)/len2))
    q=(round(a[0]+t*dx),round(a[1]+t*dy))
    return q,math.hypot(p[0]-q[0],p[1]-q[1])


def hotspots(objs: list[dict]):
    """Connection/endpoint hotspots with their native nanometre coordinates."""
    for obj in objs:
        typ=obj.get("type")
        if typ in ("pin","pad","circle","text"):
            yield (int(obj.get("x",0)),int(obj.get("y",0)))
        elif typ=="rect":
            x=int(obj["x"]);y=int(obj["y"]);w=int(obj["w"]);h=int(obj["h"])
            for p in ((x,y),(x+w,y),(x+w,y+h),(x,y+h)):
                yield p
        elif typ=="polyline":
            for p in obj.get("points",[]):yield tuple(map(int,p))


def snap_point(point: tuple[int,int], grid: Grid, objects:list[dict], snap_nm:int,
               *, exclude_id:str | None=None, include_segment:bool=True) -> tuple[tuple[int,int],str]:
    """Exact-object hotspot / segment priority before Cartesian grid.

    snap_nm is computed by the view from a fixed pixel radius, so behavior
    remains consistent while zooming. Electrical pin targets use same search.
    """
    p=tuple(map(int,point))
    if grid.electricalEnabled:
        # The schematic electrical hotspot search can override Cartesian
        # placement even when general object snapping is disabled.
        best=None;best_d=float('inf')
        radius=min(snap_nm,grid.electricalRange)
        for obj in objects:
            if obj.get('id')==exclude_id or obj.get('type')!='pin':continue
            pt=(int(obj['x']),int(obj['y']))
            dist=math.hypot(p[0]-pt[0],p[1]-pt[1])
            if dist<=radius and dist<best_d:
                best,best_d=pt,dist
        if best is not None:return best,'Electrical'
    if grid.objectSnap:
        snap_nm=min(snap_nm,grid.hotspotRange)
        # Priority is hotspot > segment > Cartesian grid. If a hotspot is
        # close enough, it wins even when the cursor is closer to an edge.
        best=None;distance=float("inf")
        for obj in objects:
            if obj.get("id")==exclude_id:continue
            for q in hotspots([obj]):
                d=math.hypot(p[0]-q[0],p[1]-q[1])
                if d <= snap_nm and d < distance:best=q;distance=d
        if best is not None:return best,"Hotspot"
        if include_segment:
            best=None;distance=float("inf")
            for obj in objects:
                if obj.get("id")==exclude_id or obj.get("type")!="polyline":continue
                pts=[tuple(map(int,a)) for a in obj.get("points",[])]
                if obj.get("closed") and len(pts)>2:pts.append(pts[0])
                for a,b in zip(pts,pts[1:]):
                    q,d=point_to_segment_projection(p,a,b)
                    if d <= snap_nm and d < distance:best=q;distance=d
            if best is not None:return best,"Segment"
    if grid.snapEnabled: return grid.snap(p),"Grid"
    return p,"Free"


def offset_geometry(obj: dict, dx:int,dy:int) -> dict:
    result=copy.deepcopy(obj)
    if obj.get("type")=="polyline":
        result["points"]=[[int(x)+dx,int(y)+dy] for x,y in obj.get("points",[])]
    else:
        result["x"] = int(obj.get("x",0))+dx
        result["y"] = int(obj.get("y",0))+dy
    return result


def validate_design(obj:dict, *, mode:str) -> list[dict]:
    shapes=obj.get("symbol",[]) if mode=="sch" else obj.get("pcb",[])
    grid=Grid.from_mapping(obj.get("grid"),pcb=(mode=="pcb"))
    issues=[];refs=set()
    for i,s in enumerate(shapes):
        name=s.get("type","unknown")
        if name in ("pin","pad"):
            number=str(s.get("number",""))
            if not number: issues.append({"level":"error","message":f"{i+1}: boş pin/pad numarası"})
            elif number in refs:issues.append({"level":"error","message":f"Tekrarlanan pin/pad numarası: {number}"})
            refs.add(number)
        if name=="pad" and (s.get("w",0)<=0 or s.get("h",0)<=0):
            issues.append({"level":"error","message":f"{i+1}: pad boyutu sıfır veya negatif"})
        if name=="polyline" and len(s.get("points",[]))<2:
            issues.append({"level":"error","message":f"{i+1}: eksik polyline"})
        if name in ("pin","pad","circle","text"):
            points=[(s.get("x",0),s.get("y",0))]
        elif name=="rect":points=[(s.get("x",0),s.get("y",0)),(s.get("x",0)+s.get("w",0),s.get("y",0)+s.get("h",0))]
        elif name=="polyline":points=[tuple(p) for p in s.get("points",[])]
        else:points=[]
        if grid.strictGrid:
            for p in points:
                if grid.snap(tuple(map(int,p))) != tuple(map(int,p)):
                    issues.append({"level":"warning","message":f"{i+1} {name}: grid dışı koordinat"})
                    break
    if not shapes:issues.append({"level":"warning","message":"Çizim boş"})
    return issues
