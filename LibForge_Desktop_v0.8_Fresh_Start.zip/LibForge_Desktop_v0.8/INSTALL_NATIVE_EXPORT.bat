@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Once START_WINDOWS.bat dosyasini calistirin.
 pause
 exit /b 1
)
echo Native export araci AGPL-3.0-or-later lisansli altium-monkey kullanir.
echo Kurumsal veya ticari kullanimda lisans yukumluluklerini inceleyin.
".venv\Scripts\python.exe" -m pip install -r requirements-native-export.txt
if errorlevel 1 (pause & exit /b 1)
echo Kurulum tamamlandi. Uygulamadan File ^> Export Native secin.
pause
