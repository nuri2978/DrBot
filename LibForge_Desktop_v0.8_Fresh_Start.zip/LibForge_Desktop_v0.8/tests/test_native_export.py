import sys
from pathlib import Path
from types import SimpleNamespace
import native_export as ne
from core import empty_project, Grid, make_id


class FakeSymbol:
    def __init__(self):self.objects=[]
    def set_description(self,*a):self.objects.append(('description',a))
    def set_part_count(self,*a):self.objects.append(('parts',a))
    def add_rectangle(self,*a,**k):self.objects.append(('rect',a,k))
    def add_polyline(self,*a,**k):self.objects.append(('poly',a,k))
    def add_polygon(self,*a,**k):self.objects.append(('polygon',a,k))
    def add_ellipse(self,*a,**k):self.objects.append(('ellipse',a,k))
    def add_pin(self,*a,**k):self.objects.append(('pin',a,k))
    def add_label(self,*a,**k):self.objects.append(('text',a,k))
    def add_designator(self,*a):self.objects.append(('desig',a))


class FakeLib:
    def __init__(self,**kw):self.symbols=[];self.footprints=[]
    def add_symbol(self,name):
        self.symbols.append((name,FakeSymbol()))
        return self.symbols[-1][1]
    def add_footprint(self,name,**kw):
        self.footprints.append((name,FakeFootprint()))
        return self.footprints[-1][1]
    def save(self,path):Path(path).write_bytes(b'Native mock '+b'\0'*1024)


class FakeFootprint:
    def __init__(self):self.objects=[]
    def add_pad(self,**kwargs):self.objects.append(('pad',kwargs))
    def add_track(self,*args,**kwargs):self.objects.append(('track',args,kwargs))
    def add_arc(self,**kwargs):self.objects.append(('arc',kwargs))


class FakePin:
    def __init__(self):self.owner_part_id=1


def monkey_fake(monkeypatch):
    class PinElectrical:PASSIVE='Passive';INPUT='Input';OUTPUT='Output';POWER='Power'
    class Rotation90:DEG_0=0;DEG_90=90;DEG_180=180;DEG_270=270
    class PadShape:RECTANGLE='r';CIRCLE='c';ROUNDED_RECTANGLE='rounded'
    class PcbLayer:TOP='top';BOTTOM='bottom';TOP_OVERLAY='overlay';BOTTOM_OVERLAY='bottom_overlay';MULTI_LAYER='multi'
    fake=SimpleNamespace(AltiumSchLib=FakeLib,AltiumPcbLib=FakeLib,PinElectrical=PinElectrical,
        Rotation90=Rotation90,PadShape=PadShape,PcbLayer=PcbLayer,
        SchPointMils=SimpleNamespace(from_mils=lambda x,y:(x,y)),
        SchFontSpec=lambda **x:x,
        make_sch_pin=lambda **x:FakePin())
    monkeypatch.setattr(ne,'_import_altium',lambda:fake)
    return fake


def sample_project():
    from dataclasses import asdict
    p=empty_project()
    fp={"id":"test_fp", "name":"SOIC8_DEMO", "category":"SMD/SOIC",
        "pcb":[{"type":"pad","x":0,"y":0,"w":500000,"h":800000,
                 "number":"1","shape":"rect","layer":"Top Layer"}],
        "grid":asdict(Grid.pcb())}
    symbol={"id":"test_sym", "name":"OPA_DEMO", "category":"IC/Opamp",
            "symbol":[{"type":"rect","x":0,"y":0,"w":2540000,"h":2540000},
                      {"type":"pin","x":-5080000,"y":0,"length":2540000,
                       "side":"right","name":"IN","number":"1"}],
            "grid":asdict(Grid()), "footprintId":fp["id"]}
    p["footprints"].append(fp);p["components"].append(symbol)
    return p


def test_native_staged_files(monkeypatch,tmp_path):
    from dataclasses import asdict
    monkey_fake(monkeypatch)
    p=empty_project()
    p['components'].append({'id':'c1','name':'U_TEST','category':'IC/Opamp',
                            'symbol':[{'type':'rect','x':0,'y':0,'w':2540000,'h':2540000}],
                            'grid':asdict(Grid())})
    p['footprints'].append({'id':'f1','name':'SOIC8','category':'SMD/SOIC',
                            'pcb':[{'type':'pad','x':0,'y':0,'w':600000,'h':1000000,
                                    'number':'1','shape':'rect','layer':'Top Layer'}],
                            'grid':asdict(Grid.pcb())})
    result=ne.export_project(p,tmp_path)
    assert '2 adet' in result
    assert (tmp_path/'SchLib'/'IC'/'Opamp'/'U_TEST.SchLib').exists()
    assert (tmp_path/'PcbLib'/'SMD'/'SOIC'/'SOIC8.PcbLib').exists()
    import pytest
    with pytest.raises(FileExistsError):ne.export_project(p,tmp_path)


def test_empty_project_cannot_export(monkeypatch,tmp_path):
    import pytest
    monkey_fake(monkeypatch)
    with pytest.raises(ValueError):ne.export_project(empty_project(),tmp_path)


def test_names_safe():
    assert ne.safe_path_piece('../abc')=='abc'
