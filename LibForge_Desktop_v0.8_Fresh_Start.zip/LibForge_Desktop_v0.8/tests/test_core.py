from pathlib import Path
from tempfile import TemporaryDirectory
import json
from core import Grid,unit_to_nm,nm_to_unit,snap_1d,snap_point,empty_project,save_project,load_project,validate_design


def test_units_are_exact():
    assert unit_to_nm("0.05","mm")==50_000
    assert unit_to_nm("100","mil")==2_540_000
    assert unit_to_nm("-0.0254","mm")==-25_400
    assert nm_to_unit(2_540_000,"mil")==100


def test_grid_origin_and_negative():
    g=Grid(snapX=100,snapY=200,originX=25,originY=-25)
    assert g.snap((171,279))==(125,375)
    assert snap_1d(-50,0,100)==-100
    assert snap_1d(50,0,100)==100


def test_hotspot_precedes_grid():
    g=Grid(snapX=2_540_000,snapY=2_540_000,objectSnap=True)
    o=[{"type":"polyline","id":"a","points":[[1_000_000,0],[1_000_000,4_000_000]]}]
    p,why=snap_point((950_000,2_000_000),g,o,120_000)
    assert p==(1_000_000,2_000_000) and why=="Segment"
    p,why=snap_point((1_010_000,10_000),g,o,120_000)
    assert p==(1_000_000,0) and why=="Hotspot"
    assert snap_point((2_000_000,2_000_000),g,o,10_000)==((2_540_000,2_540_000),"Grid")


def test_save_load():
    p=empty_project()
    assert not p["components"] and not p["footprints"]
    with TemporaryDirectory() as d:
        path=Path(d)/"sample.json";save_project(path,p)
        loaded=load_project(path)
        assert loaded["components"]==[]
        assert loaded["categories"]["footprints"][0]=="SMD/QFN"


def test_old_project_rejected():
    from core import normalize_project
    import pytest
    with pytest.raises(ValueError):
        normalize_project({"version": 7, "components": [], "footprints": []})


def test_duplicate_pin():
    from dataclasses import asdict
    item={"name":"U1","symbol":[{"type":"pin","number":"1","x":0,"y":0},
                                          {"type":"pin","number":"1","x":0,"y":0}],
          "grid":asdict(Grid())}
    assert any(x["level"]=="error" for x in validate_design(item,mode="sch"))


def test_electrical_hotspot_when_object_snap_disabled():
    g=Grid(objectSnap=False,electricalEnabled=True,snapX=2_540_000,snapY=2_540_000)
    objs=[{'id':'p1','type':'pin','x':1_000_000,'y':0}]
    assert snap_point((950_000,5_000),g,objs,110_000)==((1_000_000,0),'Electrical')
    g.electricalEnabled=False
    assert snap_point((950_000,5_000),g,objs,110_000)[1]=='Grid'
