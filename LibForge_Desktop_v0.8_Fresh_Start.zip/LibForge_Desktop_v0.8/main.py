"""LibForge CAD Desktop v0.8 — dark, dockable, Altium-inspired CAD prototype."""
from __future__ import annotations

import sys
from dataclasses import asdict
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QDockWidget, QVBoxLayout,
    QHBoxLayout, QPushButton, QTreeWidget, QTreeWidgetItem, QTabWidget,
    QFormLayout, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox,
    QLineEdit, QGroupBox, QTableWidget, QTableWidgetItem, QFileDialog,
    QMessageBox, QInputDialog, QHeaderView, QPlainTextEdit, QToolBar,
    QAbstractItemView, QSplitter, QFrame)

from core import (Grid, unit_to_nm, nm_to_unit, make_id, empty_project,
                  load_project, save_project, validate_design)
from editor import CadCanvas

QSS = '''
QMainWindow,QDialog,QWidget {background:#17212e;color:#d5deea;font:10pt 'Segoe UI';}
QMenuBar {background:#202c3c;border-bottom:1px solid #33475d;}
QMenuBar::item:selected,QMenu::item:selected {background:#344d63;}
QMenu {background:#253449;border:1px solid #4d6580;}
QToolBar {background:#202c3c;padding:7px;spacing:6px;border-bottom:1px solid #324459;}
QToolButton {padding:7px;border:1px solid transparent;border-radius:4px;}
QToolButton:hover {background:#344b61;}
QToolButton:checked {background:#11636c;border:1px solid #38abac;}
QDockWidget {background:#202c3c;color:#cfd9e6;font-weight:bold;titlebar-close-icon:none;}
QDockWidget::title {background:#263549;padding:9px;border-bottom:1px solid #3b5167;}
QTreeWidget,QTableWidget,QPlainTextEdit {background:#192535;alternate-background-color:#202d3d;
    border:1px solid #3a4c60;border-radius:4px;gridline-color:#354a5e;}
QTreeWidget::item {height:25px;}
QTreeWidget::item:selected,QTableWidget::item:selected {background:#1f6574;}
QPushButton {background:#2c4155;border:1px solid #3b5266;border-radius:5px;padding:7px 10px;}
QPushButton:hover {background:#3b5770;} QPushButton:pressed {background:#1a6b71;}
QLineEdit,QComboBox,QDoubleSpinBox,QSpinBox {background:#111c29;border:1px solid #3c5064;
    border-radius:4px;padding:6px;color:#e4edf9;min-height:20px;}
QComboBox QAbstractItemView {background:#203348;color:#e7f4ff;selection-background-color:#205f70;}
QCheckBox {padding:4px;} QCheckBox::indicator {width:15px;height:15px;}
QTabBar::tab {background:#263548;color:#b9c8d7;border:1px solid #34475a;padding:10px 16px;}
QTabBar::tab:selected {background:#165e6d;color:white;border-bottom:2px solid #3bd2c4;}
QTabWidget::pane {border:1px solid #344b5f;}
QStatusBar {background:#202f3e;color:#bac9d7;border-top:1px solid #34475a;}
QHeaderView::section {background:#2a3c4f;color:#d5e3ef;border:none;padding:7px;}
QGroupBox {border:1px solid #3b5063;border-radius:5px;margin-top:14px;padding:13px 8px 8px;}
QGroupBox::title {subcontrol-origin:margin;left:8px;color:#8de1dc;}
'''


class GridPanel(QWidget):
    """Separate display/snap/electrical grid controls with per-mode persistence."""
    def __init__(self, canvas:CadCanvas, parent=None):
        super().__init__(parent)
        self.canvas=canvas
        layout=QVBoxLayout(self)
        grp=QGroupBox('Grid Manager — Cartesian')
        f=QFormLayout(grp)
        self.unit=QComboBox();self.unit.addItems(['mil','mm'])
        self.unit.currentTextChanged.connect(self.unit_changed)
        f.addRow('Birim',self.unit)
        self.fields={}
        for key,label in [('snapX','Snap X'),('snapY','Snap Y'),('visibleX','Visible X'),('visibleY','Visible Y'),
                          ('originX','Origin X'),('originY','Origin Y'),
                          ('hotspotRange','Object Snap Range'),('electricalRange','Electrical Range')]:
            e=QDoubleSpinBox();e.setDecimals(5);e.setRange(-100_000,100_000)
            e.setSingleStep(0.05);e.setKeyboardTracking(False)
            f.addRow(label,e);self.fields[key]=e
        self.coarse=QSpinBox();self.coarse.setRange(2,20);f.addRow('Coarse factor',self.coarse)
        self.style=QComboBox();self.style.addItems(['dots','lines','hidden']);f.addRow('Görünüm',self.style)
        self.snap=QCheckBox('Snap to grid');f.addRow(self.snap)
        self.show=QCheckBox('Show visible grid');f.addRow(self.show)
        self.object=QCheckBox('Snap to object hotspots / edges');f.addRow(self.object)
        self.strict=QCheckBox('Off-grid QA warnings');f.addRow(self.strict)
        self.elec=QCheckBox('Electrical pin snap (schematic)');f.addRow(self.elec)
        layout.addWidget(grp)
        row=QHBoxLayout()
        btn=QPushButton('✓ Grid ayarlarını uygula');btn.clicked.connect(self.apply);row.addWidget(btn)
        layout.addLayout(row)
        tip=QLabel('Altium mantığı: Visible Grid yalnızca görüntü içindir; Snap Grid yerleşimi belirler.\n'
                   'Hotspot/segment önceliği, grid dışındaki uçları da tam birleştirir.')
        tip.setWordWrap(True);tip.setStyleSheet('color:#94aabc;font-size:9pt;padding:8px;')
        layout.addWidget(tip);layout.addStretch(1)
        self._display_unit='mil'

    def populate(self):
        g=self.canvas.grid
        self.unit.blockSignals(True);self.unit.setCurrentText(g.unit);self.unit.blockSignals(False)
        self._display_unit=g.unit
        for name,field in self.fields.items():
            field.setValue(nm_to_unit(getattr(g,name),g.unit))
        self.coarse.setValue(g.coarse);self.style.setCurrentText(g.style)
        self.snap.setChecked(g.snapEnabled);self.show.setChecked(g.showGrid)
        self.object.setChecked(g.objectSnap);self.strict.setChecked(g.strictGrid)
        self.elec.setChecked(g.electricalEnabled)
        self.elec.setEnabled(self.canvas.mode=='sch')

    def unit_changed(self,unit):
        previous=self._display_unit
        for field in self.fields.values():
            v=unit_to_nm(field.value(),previous)
            field.setValue(nm_to_unit(v,unit))
        self._display_unit=unit

    def apply(self):
        g=self.canvas.grid
        g.unit=self.unit.currentText()
        for name,fld in self.fields.items():setattr(g,name,unit_to_nm(fld.value(),g.unit))
        if min(g.snapX,g.snapY,g.visibleX,g.visibleY)<=0:
            QMessageBox.warning(self,'Grid','Snap ve Visible Grid değerleri sıfırdan büyük olmalı.');return
        g.coarse=self.coarse.value();g.style=self.style.currentText()
        g.snapEnabled=self.snap.isChecked();g.showGrid=self.show.isChecked()
        g.objectSnap=self.object.isChecked();g.strictGrid=self.strict.isChecked()
        g.electricalEnabled=self.elec.isChecked()
        self.canvas.set_grid(g)


class PropertiesPanel(QWidget):
    def __init__(self,canvas:CadCanvas):
        super().__init__()
        self.canvas=canvas
        self.layout=QVBoxLayout(self)
        self.form=QFormLayout()
        self.layout.addLayout(self.form)
        self.layout.addStretch(1)
        self.populate()

    def populate(self):
        while self.form.rowCount():self.form.removeRow(0)
        item=self.canvas.selected()
        if item is None:
            self.form.addRow(QLabel('Nesne seç: pin, pad, overlay, çerçeve...'))
            return
        self.form.addRow('Nesne',QLabel(item.get('type','?').upper()))
        base=['number','name','electrical','layer','shape','side','rotation','x','y','w','h','length','radius']
        for k in base:
            if k not in item:continue
            if k in ('x','y','w','h','length','radius'):
                spin=QDoubleSpinBox();spin.setRange(-1_000_000,1_000_000);spin.setDecimals(5)
                spin.setValue(nm_to_unit(item[k],self.canvas.grid.unit))
                spin.editingFinished.connect(lambda k=k,w=spin:self.on_edit(k,unit_to_nm(w.value(),self.canvas.grid.unit)))
                self.form.addRow(f'{k.upper()} ({self.canvas.grid.unit})',spin)
            else:
                line=QLineEdit(str(item.get(k,'')))
                line.editingFinished.connect(lambda k=k,w=line:self.on_edit(k,w.text()))
                self.form.addRow(k.capitalize(),line)
        if item.get('type')=='polyline':
            self.form.addRow('Nokta',QLabel(f'{len(item.get("points",[]))} köşe — CAD üzerinde düzenle'))

    def on_edit(self,key,value):
        o=self.canvas.selected()
        if o is None:return
        if key=='rotation':
            try:value=float(value)
            except ValueError:return
        if o.get(key)==value:return
        self.canvas.checkpoint();o[key]=value
        self.canvas.update();self.canvas.changed.emit()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('LibForge CAD v0.8 — Library Designer')
        self.resize(1530,900)
        self.project=empty_project()
        self.project_path=None
        self.canvas=CadCanvas(self)
        self.canvas.changed.connect(self.after_change)
        self.canvas.selectedChanged.connect(self.selected_update)
        self.canvas.cursorMoved.connect(self.statusBar().showMessage)
        self.make_center()
        self.make_tools()
        self.make_docks()
        self.refresh_tree()
        self.refresh_table()
        self.grid_panel.populate()
        self.statusBar().showMessage('Yeni bir kütüphane için New Component veya New Footprint seçin.')

    def make_center(self):
        wrap=QWidget();lyt=QVBoxLayout(wrap);lyt.setContentsMargins(0,0,0,0);lyt.setSpacing(0)
        header=QHBoxLayout()
        self.doc_title=QLabel('Untitled LibForge Project  —  New Component / New Footprint')
        self.doc_title.setStyleSheet('font-weight:600;color:#b8e5e9;background:#25384a;padding:12px;border-bottom:1px solid #426073;')
        header.addWidget(self.doc_title,1)
        self.mode_tag=QLabel('SCH  |  100 mil')
        self.mode_tag.setStyleSheet('color:#89d6cb;background:#243646;padding:12px;')
        header.addWidget(self.mode_tag)
        lyt.addLayout(header);lyt.addWidget(self.canvas,1)
        self.setCentralWidget(wrap)

    def make_tools(self):
        file_menu=self.menuBar().addMenu('File')
        edit_menu=self.menuBar().addMenu('Edit')
        place_menu=self.menuBar().addMenu('Place')
        view_menu=self.menuBar().addMenu('View')
        tools_menu=self.menuBar().addMenu('Tools')
        self.toolbar=QToolBar('CAD tools');self.toolbar.setMovable(True)
        self.addToolBar(self.toolbar)
        def action(text,fun,shortcut=None,checked=False,menu=None):
            act=QAction(text,self);act.triggered.connect(fun)
            if shortcut:act.setShortcut(QKeySequence(shortcut))
            if checked:act.setCheckable(True)
            self.toolbar.addAction(act)
            if menu:menu.addAction(act)
            return act
        action('New Project',self.new_project,menu=file_menu)
        action('New Component',self.add_component,menu=file_menu)
        action('New Footprint',self.add_footprint,menu=file_menu)
        self.toolbar.addSeparator()
        action('Open Project',self.open_project,'Ctrl+O',menu=file_menu)
        action('Save Project',self.save_project,'Ctrl+S',menu=file_menu)
        action('Export Native',self.export_native,menu=file_menu)
        self.toolbar.addSeparator()
        self.actions={}
        choices=[('Select','select','V'),('Polyline','polyline','W'),('Line','line','L'),
                 ('Rectangle','rect','R'),('Circle','circle','C'),('Pin','pin','P'),('Pad','pad','A')]
        for text,tool,key in choices:
            def set_t(t=tool):
                if t=='pin' and self.canvas.mode!='sch':self.show_message('Pin yalnızca SchLib editöründe.');return
                if t=='pad' and self.canvas.mode!='pcb':self.show_message('Pad yalnızca PcbLib editöründe.');return
                self.canvas.set_tool(t)
                for name,a in self.actions.items():a.setChecked(name==t)
            act=action(text,set_t,key,checked=True,menu=place_menu)
            self.actions[tool]=act
        self.actions['select'].setChecked(True)
        self.toolbar.addSeparator()
        action('Undo',self.canvas.undo,'Ctrl+Z',menu=edit_menu)
        action('Redo',self.canvas.redo,'Ctrl+Y',menu=edit_menu)
        action('Delete',self.canvas.delete_selected,'Del',menu=edit_menu)
        action('QA Check',self.quality_check,menu=tools_menu)
        action('Zoom +',lambda:self.canvas.zoom(1.25),menu=view_menu)
        action('Zoom −',lambda:self.canvas.zoom(.8),menu=view_menu)

    def make_docks(self):
        self.tree=QTreeWidget();self.tree.setHeaderHidden(True)
        self.tree.itemDoubleClicked.connect(self.tree_activate)
        left_widget=QWidget();l=QVBoxLayout(left_widget);l.setContentsMargins(7,7,7,7)
        l.addWidget(self.tree,1)
        buttons=QHBoxLayout()
        for txt,fun in [('+ Component',self.add_component),('+ Footprint',self.add_footprint),('+ Category',self.add_category)]:
            btn=QPushButton(txt);btn.clicked.connect(fun);buttons.addWidget(btn)
        l.addLayout(buttons)
        dock=QDockWidget('PROJECTS / LIBRARY EXPLORER',self);dock.setWidget(left_widget)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea,dock)
        dock.setMinimumWidth(270)
        self.tabs=QTabWidget()
        self.properties=PropertiesPanel(self.canvas)
        self.grid_panel=GridPanel(self.canvas)
        self.tabs.addTab(self.properties,'Properties')
        self.tabs.addTab(self.grid_panel,'Grid / Snap')
        right=QDockWidget('PROPERTIES / GRID MANAGER',self);right.setWidget(self.tabs)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,right)
        right.setMinimumWidth(305)
        self.tabs.setCurrentIndex(1)
        self.table=QTableWidget(0,5)
        self.table.setHorizontalHeaderLabels(['Designator','Category','Description','Footprint','Revision'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.cellChanged.connect(self.table_changed)
        self.table.cellDoubleClicked.connect(self.table_open)
        self.qa=QPlainTextEdit();self.qa.setReadOnly(True)
        bottom_tabs=QTabWidget();bottom_tabs.addTab(self.table,'Component Database')
        bottom_tabs.addTab(self.qa,'Design Rule Check (QA)')
        bottom=QDockWidget('DATABASE / QUALITY CONTROL',self);bottom.setWidget(bottom_tabs)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea,bottom)
        self.resizeDocks([bottom],[212],Qt.Orientation.Vertical)
        self.bottom_tabs=bottom_tabs

    def show_message(self,msg):QMessageBox.information(self,'LibForge',msg)

    def refresh_tree(self):
        self.tree.blockSignals(True);self.tree.clear()
        root_comp=QTreeWidgetItem(self.tree,['SchLib / Components'])
        root_fp=QTreeWidgetItem(self.tree,['PcbLib / Footprints'])
        for root,section,records in ((root_comp,'components',self.project['components']),
                                     (root_fp,'footprints',self.project['footprints'])):
            nodes={'':root}
            categories=set(self.project.get('categories',{}).get(section,[])) | {x.get('category','Other') for x in records}
            for cat in sorted(categories):
                parts=[x for x in cat.split('/') if x];parent=root;prefix=''
                for part in parts:
                    prefix=f'{prefix}/{part}' if prefix else part
                    if prefix not in nodes:
                        nodes[prefix]=QTreeWidgetItem(parent,[part])
                    parent=nodes[prefix]
            for obj in sorted(records,key=lambda o:o.get('name','')):
                parent=nodes.get(obj.get('category',''),root)
                leaf=QTreeWidgetItem(parent,[obj.get('name','Unnamed')]);leaf.setData(0,Qt.ItemDataRole.UserRole,(section,obj['id']))
        self.tree.expandToDepth(2)
        self.tree.blockSignals(False)

    def tree_activate(self,item,col):
        data=item.data(0,Qt.ItemDataRole.UserRole)
        if isinstance(data,tuple):self.switch_to('sch' if data[0]=='components' else 'pcb',data[1])

    def switch_to(self,mode,owner_id):
        section='components' if mode=='sch' else 'footprints'
        owner=next((x for x in self.project[section] if x['id']==owner_id),None)
        if owner is None:return
        self.canvas.open(mode,owner)
        self.canvas.set_tool('select')
        for k,a in self.actions.items():a.setChecked(k=='select')
        self.doc_title.setText(f'{owner.get("name","Unnamed")}.{ "SchLib" if mode=="sch" else "PcbLib"} — '
                               f'{"Schematic Symbol" if mode=="sch" else "PCB Footprint"}')
        self.project['active' if mode=='sch' else 'activeFootprint']=owner['id']
        self.grid_panel.populate();self.properties.populate();self.update_mode_tag()

    def update_mode_tag(self):
        g=self.canvas.grid
        self.mode_tag.setText(f'{self.canvas.mode.upper()}  |  Snap: {nm_to_unit(g.snapX,g.unit):g} × {nm_to_unit(g.snapY,g.unit):g} {g.unit}')

    def selected_update(self):self.properties.populate();self.tabs.setCurrentIndex(0 if self.canvas.selected() else 1)

    def after_change(self):
        self.update_mode_tag()
        self.grid_panel.populate()
        self.refresh_table()

    def new_project(self):
        reply=QMessageBox.question(self,'New Project',
            'Mevcut çalışma alanını kapatıp sıfırdan yeni proje oluşturulsun mu?\n'
            'Kaydedilmemiş değişiklikler kaybolabilir.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:return
        self.project=empty_project()
        self.project_path=None
        self.refresh_tree();self.refresh_table()
        self.canvas.open('sch',{})
        self.doc_title.setText('Untitled LibForge Project  —  New Component / New Footprint')
        self.grid_panel.populate();self.properties.populate();self.update_mode_tag()

    def add_component(self):
        name,ok=QInputDialog.getText(self,'New SchLib','Component name / MPN:')
        if not ok or not name.strip():return
        if any(c.get('name','').casefold()==name.strip().casefold() for c in self.project['components']):
            self.show_message('Bu komponent adı zaten mevcut.');return
        category,ok=QInputDialog.getText(self,'Category','Category path:',text='IC/Opamp')
        if not ok:return
        cat=category.strip() or 'IC/Other'
        footprint_id=None
        if self.project['footprints']:
            choices=['(Atanmamış)']+[f['name'] for f in self.project['footprints']]
            selected,ok=QInputDialog.getItem(self,'PCB Footprint Assignment',
                                            'Var olan footprint seç:',choices,0,False)
            if not ok:return
            match=next((f for f in self.project['footprints'] if f['name']==selected),None)
            if match:footprint_id=match['id']
        comp={'id':make_id(),'name':name.strip(),'category':cat,'description':'',
              'symbol':[],'grid':asdict(Grid()),'footprintId':footprint_id,'revision':'A'}
        self.project['components'].append(comp)
        cats=self.project['categories'].setdefault('components',[])
        if cat not in cats:cats.append(cat)
        self.refresh_tree();self.refresh_table();self.switch_to('sch',comp['id'])

    def add_footprint(self):
        name,ok=QInputDialog.getText(self,'New PcbLib','Footprint name:')
        if not ok or not name.strip():return
        if any(f.get('name','').casefold()==name.strip().casefold() for f in self.project['footprints']):
            self.show_message('Bu footprint adı zaten mevcut.');return
        cat,ok=QInputDialog.getText(self,'Category','Category path:',text='SMD/QFN')
        if not ok:return
        cat=cat.strip() or 'SMD/Other'
        obj={'id':make_id(),'name':name.strip(),'category':cat,'pcb':[],'grid':asdict(Grid.pcb()),'stepPath':''}
        self.project['footprints'].append(obj)
        cats=self.project['categories'].setdefault('footprints',[])
        if cat not in cats:cats.append(cat)
        self.refresh_tree();self.refresh_table();self.switch_to('pcb',obj['id'])

    def add_category(self):
        choices=['SchLib / Components','PcbLib / Footprints']
        which,ok=QInputDialog.getItem(self,'Category type','Library:',choices,0,False)
        if not ok:return
        cat,ok=QInputDialog.getText(self,'New Category','Path (example SMD/QFN):')
        if ok and cat.strip():
            section='components' if which==choices[0] else 'footprints'
            categories=self.project['categories'].setdefault(section,[])
            if cat.strip() not in categories:categories.append(cat.strip())
            self.refresh_tree()

    def refresh_table(self):
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.project['components']))
        fplist=self.project['footprints']
        for r,c in enumerate(self.project['components']):
            footprint=next((x.get('name') for x in fplist if x['id']==c.get('footprintId')),'')
            values=[c.get('name',''),c.get('category',''),c.get('description',''),footprint,c.get('revision','A')]
            for col,value in enumerate(values):
                it=QTableWidgetItem(str(value));it.setData(Qt.ItemDataRole.UserRole,c['id'])
                self.table.setItem(r,col,it)
        self.table.blockSignals(False)

    def table_changed(self,row,col):
        item=self.table.item(row,col)
        if not item:return
        cid=item.data(Qt.ItemDataRole.UserRole)
        c=next((x for x in self.project['components'] if x['id']==cid),None)
        if not c:return
        val=item.text().strip()
        if col==3:
            matching=next((x for x in self.project['footprints'] if x['name']==val),None)
            if val and matching is None:
                self.show_message('Footprint bulunamadı. Library Explorer üzerinden önce oluştur.')
                self.refresh_table();return
            c['footprintId']=matching['id'] if matching else None
        else:
            c[['name','category','description','footprintId','revision'][col]]=val
        self.refresh_tree()

    def table_open(self,row,col):
        if row<len(self.project['components']):self.switch_to('sch',self.project['components'][row]['id'])

    def quality_check(self):
        lines=[];errors=warnings=0
        for mode,coll in [('sch',self.project['components']),('pcb',self.project['footprints'])]:
            for obj in coll:
                issues=validate_design(obj,mode=mode)
                lines.append(f'[{mode.upper()}] {obj.get("name", "?")} — {len(issues)} issue(s)')
                for it in issues:
                    if it['level']=='error':errors+=1
                    else:warnings+=1
                    lines.append(f'  {it["level"].upper()}: {it["message"]}')
        lines.insert(0,f'Design Rule Check | {errors} errors, {warnings} warnings\n')
        self.qa.setPlainText('\n'.join(lines));self.bottom_tabs.setCurrentIndex(1)
        return errors

    def open_project(self):
        p,_=QFileDialog.getOpenFileName(self,'Open LibForge project','','LibForge Desktop JSON (*.json)')
        if not p:return
        try:self.project=load_project(Path(p))
        except Exception as e:QMessageBox.critical(self,'Open failed',str(e));return
        self.project_path=Path(p)
        self.refresh_tree();self.refresh_table()
        if self.project['components']:self.switch_to('sch',self.project['components'][0]['id'])
        elif self.project['footprints']:self.switch_to('pcb',self.project['footprints'][0]['id'])
        else:self.canvas.open('sch',{})

    def save_project(self):
        if self.project_path is None:
            p,_=QFileDialog.getSaveFileName(self,'Save editable LibForge project','LibForge_Project.json','JSON (*.json)')
            if not p:return
            self.project_path=Path(p)
        try:save_project(self.project_path,self.project)
        except Exception as e:QMessageBox.critical(self,'Save failed',str(e))
        else:self.statusBar().showMessage(f'Project saved: {self.project_path}',8000)

    def export_native(self):
        # Export is separate from saving the editable project; it never relabels
        # a JSON file with an Altium native extension.
        folder=QFileDialog.getExistingDirectory(self,'Export native Altium libraries')
        if not folder:return
        try:
            from native_export import export_project
            report=export_project(self.project,Path(folder))
            self.show_message(report)
        except ImportError:
            QMessageBox.warning(self,'Export dependencies',
                'Native export için Python 3.12+ ve altium-monkey kurulu olmalı.\n'
                'Komut: python -m pip install altium-monkey')
        except Exception as e:
            QMessageBox.critical(self,'Native export failed',str(e))


def main():
    app=QApplication(sys.argv)
    app.setApplicationName('LibForge CAD Desktop')
    app.setStyle('Fusion');app.setStyleSheet(QSS)
    window=MainWindow();window.show()
    return app.exec()


if __name__=='__main__':raise SystemExit(main())
