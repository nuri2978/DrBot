"""PySide6 drawing canvas and application shell for LibForge Desktop 0.8.

Canvas has no floating-point grid persistence: screen pixels are exclusively
used for presentation/hit-testing. All committed geometry is integer nm.
"""
from __future__ import annotations

import copy
import math
from dataclasses import asdict
from pathlib import Path

from PySide6.QtCore import Qt, QPoint, QPointF, QRectF, Signal, QSize
from PySide6.QtGui import (QAction, QColor, QFont, QKeySequence, QPainter,
                          QPen, QBrush, QPolygonF)
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QToolBar, QDockWidget, QTreeWidget, QTreeWidgetItem,
    QTabWidget, QFormLayout, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox,
    QLineEdit, QGroupBox, QTableWidget, QTableWidgetItem, QPushButton,
    QFileDialog, QMessageBox, QInputDialog, QSplitter, QPlainTextEdit,
    QHeaderView, QAbstractItemView)

from core import (Grid, NM_PER_MM, make_id, nm_to_unit, unit_to_nm,
                  snap_point, offset_geometry, empty_project, normalize_project,
                  load_project, save_project, validate_design, point_to_segment_projection)

BG = QColor('#121b27')
TEXT = QColor('#d5dfed')
SCHEMATIC = QColor('#84cbf2')
PIN = QColor('#e2b976')
COPPER = QColor('#e78079')
OVERLAY = QColor('#edd484')
MECHANICAL = QColor('#71b9a9')
HIGHLIGHT = QColor('#4af0c7')
GRID_FINE = QColor('#2b3b4e')
GRID_COARSE = QColor('#435569')


class CadCanvas(QWidget):
    changed = Signal()
    selectedChanged = Signal()
    cursorMoved = Signal(str)
    toolChanged = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(550,370)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.mode = 'sch'
        self.owner:dict = {}
        self.tool = 'select'
        self.selected_id = None
        self.layer='Graphics'
        self.scale=23.0  # px/mm
        self.center_x=0
        self.center_y=0
        self.mouse_raw=None
        self.mouse_snapped=None
        self.snap_reason=''
        self.poly_points=[]
        self.first_point=None
        self.temp_end=None
        self.panning=False
        self.pan_start=None
        self.dragging=False
        self.drag_start=None
        self.drag_offset=(0,0)
        self.history=[]
        self.future=[]
        self.setCursor(Qt.CursorShape.CrossCursor)

    @property
    def shapes(self):
        return self.owner.setdefault('symbol' if self.mode=='sch' else 'pcb',[])

    @property
    def grid(self):
        return Grid.from_mapping(self.owner.get('grid'),self.mode=='pcb')

    def set_grid(self, grid:Grid):
        self.owner['grid']=asdict(grid)
        self.update()
        self.changed.emit()

    def open(self, mode:str, owner:dict):
        self.mode=mode
        self.owner=owner
        self.owner.setdefault('grid',asdict(Grid.pcb() if mode=='pcb' else Grid()))
        self.owner.setdefault('symbol' if mode=='sch' else 'pcb',[])
        self.selected_id=None
        self.poly_points=[]
        self.first_point=None
        self.temp_end=None
        self.history=[];self.future=[]
        self.dragging=False
        self.layer = 'Graphics' if mode=='sch' else 'Top Overlay'
        self.scale=23.0 if mode=='sch' else 73.0
        self.center_x=0;self.center_y=0
        self.update();self.selectedChanged.emit()

    def set_tool(self, tool):
        if self.tool!='polyline' and tool=='polyline':self.poly_points=[]
        if tool!='polyline':self.poly_points=[]
        self.first_point=None;self.temp_end=None
        self.tool=tool
        self.setCursor(Qt.CursorShape.ArrowCursor if tool=='select' else Qt.CursorShape.CrossCursor)
        self.toolChanged.emit(tool)
        self.update()

    def to_pixel(self,p):
        return QPointF(self.width()/2 + (int(p[0])-self.center_x)/NM_PER_MM*self.scale,
                       self.height()/2 - (int(p[1])-self.center_y)/NM_PER_MM*self.scale)

    def from_pixel(self,p):
        return (round(self.center_x+(p.x()-self.width()/2)/self.scale*NM_PER_MM),
                round(self.center_y-(p.y()-self.height()/2)/self.scale*NM_PER_MM))

    def _snapped(self, px):
        raw=self.from_pixel(px)
        grid=self.grid
        radius= min(14/self.scale*NM_PER_MM, max(grid.snapX,grid.snapY)*1.75)
        target,why=snap_point(raw,grid,self.shapes,int(radius), exclude_id=self.selected_id if self.dragging else None)
        self.mouse_raw=raw;self.mouse_snapped=target;self.snap_reason=why
        u=grid.unit
        self.cursorMoved.emit(f'X {nm_to_unit(target[0],u):.4f}  Y {nm_to_unit(target[1],u):.4f} {u}  |  {why}')
        return target

    def checkpoint(self):
        self.history.append(copy.deepcopy(self.shapes))
        if len(self.history)>100:self.history.pop(0)
        self.future.clear()

    def undo(self):
        if self.history:
            self.future.append(copy.deepcopy(self.shapes))
            self.shapes[:]=self.history.pop()
            self.selected_id=None
            self.update();self.changed.emit();self.selectedChanged.emit()

    def redo(self):
        if self.future:
            self.history.append(copy.deepcopy(self.shapes))
            self.shapes[:]=self.future.pop()
            self.selected_id=None
            self.update();self.changed.emit();self.selectedChanged.emit()

    def selected(self):
        return next((x for x in self.shapes if x.get('id')==self.selected_id),None)

    def delete_selected(self):
        if self.selected() is not None:
            self.checkpoint();self.shapes[:]=[x for x in self.shapes if x.get('id')!=self.selected_id]
            self.selected_id=None;self.changed.emit();self.selectedChanged.emit();self.update()

    def zoom(self,factor:float,anchor=None):
        anchor=anchor or QPointF(self.width()/2,self.height()/2)
        old=self.from_pixel(anchor)
        self.scale=max(3.0,min(650.,self.scale*factor))
        new=self.from_pixel(anchor)
        self.center_x+=old[0]-new[0]
        self.center_y+=old[1]-new[1]
        self.update()

    def wheelEvent(self,event):
        self.zoom(1.15 if event.angleDelta().y()>0 else 1/1.15,event.position())
        event.accept()

    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.MiddleButton or (event.button()==Qt.MouseButton.LeftButton and event.modifiers() & Qt.KeyboardModifier.AltModifier):
            self.panning=True;self.pan_start=(event.position(),self.center_x,self.center_y)
            self.setCursor(Qt.CursorShape.ClosedHandCursor);return
        if event.button()==Qt.MouseButton.RightButton:
            if self.tool=='polyline':self.finish_polyline()
            else:self.set_tool('select')
            return
        if event.button()!=Qt.MouseButton.LeftButton:return
        if not self.owner.get('id'):
            self.cursorMoved.emit('Önce New Component veya New Footprint ile çalışma dosyası oluşturun.')
            return
        self.setFocus();p=self._snapped(event.position())
        if not self.owner.get("id") and self.tool != "select":return
        if self.tool=='select':
            obj=self.hit_test(event.position())
            self.selected_id=obj.get('id') if obj else None
            self.selectedChanged.emit()
            if obj:
                self.dragging=True
                self.drag_start=p
                self.drag_offset=(0,0)
            self.update();return
        if self.tool=='polyline':
            if len(self.poly_points)>=3 and self.dist_px(p,self.poly_points[0])<=12:
                self.finish_polyline(closed=True);return
            if not self.poly_points or p!=self.poly_points[-1]:self.poly_points.append(p)
            self.update();return
        if self.tool in ('rect','circle','line'):
            if self.first_point is None:self.first_point=p
            else:self.finish_two_point(p)
            self.update();return
        if self.tool=='pin' and self.mode=='sch':
            number=self.next_number('pin')
            self.checkpoint()
            self.shapes.append({'id':make_id(),'type':'pin','x':p[0],'y':p[1],
                'length':self.grid.snapX*2,'side':'right','number':number,
                'name':f'PIN{number}','electrical':'Passive'})
            self.changed.emit();self.update();return
        if self.tool=='pad' and self.mode=='pcb':
            number=self.next_number('pad')
            self.checkpoint()
            self.shapes.append({'id':make_id(),'type':'pad','x':p[0],'y':p[1],
                'w':600_000,'h':1_000_000,'rotation':0,'shape':'rounded',
                'number':number,'layer':'Top Layer'})
            self.changed.emit();self.update();return

    def mouseMoveEvent(self,event):
        if self.panning and self.pan_start:
            start,cx,cy=self.pan_start
            self.center_x=cx-round((event.position().x()-start.x())/self.scale*NM_PER_MM)
            self.center_y=cy+round((event.position().y()-start.y())/self.scale*NM_PER_MM)
            self.update();return
        p=self._snapped(event.position())
        if self.dragging and self.drag_start:
            self.drag_offset=(p[0]-self.drag_start[0],p[1]-self.drag_start[1])
        self.temp_end=p
        self.update()

    def mouseReleaseEvent(self,event):
        if self.panning:
            self.panning=False;self.pan_start=None
            self.setCursor(Qt.CursorShape.ArrowCursor if self.tool=='select' else Qt.CursorShape.CrossCursor)
        if self.dragging:
            if self.drag_offset!=(0,0):
                self.checkpoint()
                for idx,x in enumerate(self.shapes):
                    if x.get('id')==self.selected_id:
                        self.shapes[idx]=offset_geometry(x,*self.drag_offset)
                        break
                self.changed.emit()
            self.dragging=False;self.drag_start=None;self.drag_offset=(0,0)
            self.update()

    def mouseDoubleClickEvent(self,event):
        if self.tool=='polyline': self.finish_polyline()

    def keyPressEvent(self,event):
        k=event.key()
        if k==Qt.Key.Key_Escape:
            self.poly_points=[];self.first_point=None;self.set_tool('select')
        elif k in (Qt.Key.Key_Enter,Qt.Key.Key_Return):
            if self.tool=='polyline':self.finish_polyline()
            elif self.first_point is not None and self.temp_end:self.finish_two_point(self.temp_end)
        elif k in (Qt.Key.Key_Delete,Qt.Key.Key_Backspace):self.delete_selected()
        elif k==Qt.Key.Key_G:
            g=self.grid
            choices=[('100 mil',2_540_000),('50 mil',1_270_000),('10 mil',254_000)] if self.mode=='sch' else [('0.5 mm',500_000),('0.1 mm',100_000),('0.05 mm',50_000),('0.01 mm',10_000)]
            step=choices[(next((i for i,(_,v) in enumerate(choices) if v==g.snapX),-1)+1)%len(choices)][1]
            g.snapX=g.snapY=step;self.set_grid(g)
        else:super().keyPressEvent(event)

    def dist_px(self,a,b):
        x=self.to_pixel(a);y=self.to_pixel(b)
        return math.hypot(x.x()-y.x(),x.y()-y.y())

    def next_number(self,what):
        used=[int(o['number']) for o in self.shapes if o.get('type')==what and str(o.get('number','')).isdigit()]
        return str(max(used,default=0)+1)

    def finish_two_point(self,end):
        a=self.first_point;self.first_point=None
        if a is None or a==end:return
        self.checkpoint()
        if self.tool=='rect':
            self.shapes.append({'id':make_id(),'type':'rect','x':min(a[0],end[0]),'y':min(a[1],end[1]),
                                'w':abs(a[0]-end[0]),'h':abs(a[1]-end[1]),'layer':self.layer})
        elif self.tool=='circle':
            radius=round(math.hypot(a[0]-end[0],a[1]-end[1]))
            self.shapes.append({'id':make_id(),'type':'circle','x':a[0],'y':a[1],
                                'radius':radius,'layer':self.layer})
        elif self.tool=='line':
            self.shapes.append({'id':make_id(),'type':'polyline','points':[list(a),list(end)],
                                'closed':False,'layer':self.layer})
        self.changed.emit();self.update()

    def finish_polyline(self,closed:bool=False):
        pts=self.poly_points
        # do not persist duplicate adjacent or final closing point
        if len(pts)>1 and pts[-1]==pts[-2]:pts=pts[:-1]
        if len(pts)>=2:
            if pts[0]==pts[-1]:pts=pts[:-1];closed=True
            if len(pts)>=2:
                self.checkpoint()
                self.shapes.append({'id':make_id(),'type':'polyline','points':[list(p) for p in pts],
                                    'closed':closed and len(pts)>=3,'layer':self.layer})
                self.changed.emit()
        self.poly_points=[];self.temp_end=None;self.update()

    def hit_test(self,at):
        p=self.from_pixel(at)
        for obj in reversed(self.shapes):
            typ=obj.get('type')
            if typ=='polyline':
                pts=[tuple(x) for x in obj.get('points',[])]
                if obj.get('closed'):pts=pts+[pts[0]] if pts else pts
                for a,b in zip(pts,pts[1:]):
                    _,d=point_to_segment_projection(p,a,b)
                    if d/NM_PER_MM*self.scale<9:return obj
            elif typ=='rect':
                a=self.to_pixel((obj['x'],obj['y']));b=self.to_pixel((obj['x']+obj['w'],obj['y']+obj['h']))
                l,r=sorted([a.x(),b.x()]);t,bt=sorted([a.y(),b.y()])
                if l-7<=at.x()<=r+7 and t-7<=at.y()<=bt+7:return obj
            elif typ=='circle':
                d=math.hypot(p[0]-obj['x'],p[1]-obj['y'])
                if abs(d-obj.get('radius',0))/NM_PER_MM*self.scale<9:return obj
            elif typ=='pad':
                c=self.to_pixel((obj['x'],obj['y'])); hw=obj['w']/NM_PER_MM*self.scale/2;hh=obj['h']/NM_PER_MM*self.scale/2
                if abs(at.x()-c.x())<=hw+7 and abs(at.y()-c.y())<=hh+7:return obj
            elif typ=='pin':
                a=(obj['x'],obj['y']);length=obj.get('length',5_080_000)
                side=obj.get('side','right')
                d={'right':(length,0),'left':(-length,0),'up':(0,length),'down':(0,-length)}.get(side,(length,0))
                q=(a[0]+d[0],a[1]+d[1]);_,dist=point_to_segment_projection(p,a,q)
                if dist/NM_PER_MM*self.scale<9:return obj
        return None

    def _object_color(self,obj):
        if obj.get('type')=='pin':return PIN
        if obj.get('type')=='pad':return COPPER
        layer=obj.get('layer','Graphics')
        if self.mode=='sch':return SCHEMATIC
        if 'Overlay' in layer:return OVERLAY
        if 'Mechanical' in layer or 'Courtyard' in layer:return MECHANICAL
        return COPPER

    def draw_shape(self,painter,obj,delta=(0,0),selected=False):
        col=self._object_color(obj)
        painter.setPen(QPen(HIGHLIGHT if selected else col,2.1 if selected else 1.5))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        typ=obj.get('type'); dx,dy=delta
        pos=lambda x,y:self.to_pixel((x+dx,y+dy))
        if typ=='rect':
            a=pos(obj['x'],obj['y']);b=pos(obj['x']+obj['w'],obj['y']+obj['h'])
            painter.drawRect(QRectF(a,b).normalized())
        elif typ=='polyline':
            pts=[pos(x,y) for x,y in obj.get('points',[])]
            if len(pts)>=2:
                if obj.get('closed'):painter.drawPolygon(QPolygonF(pts))
                else:painter.drawPolyline(QPolygonF(pts))
                if selected:
                    painter.setBrush(HIGHLIGHT)
                    for pt in pts:painter.drawEllipse(pt,3.2,3.2)
                    painter.setBrush(Qt.BrushStyle.NoBrush)
        elif typ=='circle':
            painter.drawEllipse(pos(obj['x'],obj['y']),
                                max(1,obj.get('radius',100_000)/NM_PER_MM*self.scale),
                                max(1,obj.get('radius',100_000)/NM_PER_MM*self.scale))
        elif typ=='pin':
            a=pos(obj['x'],obj['y']);length=obj.get('length',5_080_000)
            d={'right':(length,0),'left':(-length,0),'up':(0,length),'down':(0,-length)}.get(obj.get('side'),(length,0))
            b=pos(obj['x']+d[0],obj['y']+d[1]);painter.drawLine(a,b)
            painter.setBrush(PIN);painter.drawEllipse(a,3,3);painter.setBrush(Qt.BrushStyle.NoBrush)
            font=painter.font();font.setPointSize(9);painter.setFont(font)
            painter.drawText(QPointF(b.x()+5,b.y()-5),f"{obj.get('name','')} [{obj.get('number','')}]" )
        elif typ=='pad':
            c=pos(obj['x'],obj['y']);w=max(1,obj['w']/NM_PER_MM*self.scale);h=max(1,obj['h']/NM_PER_MM*self.scale)
            painter.save();painter.translate(c);painter.rotate(-obj.get('rotation',0))
            painter.setBrush(QBrush(QColor('#9e4546')))
            r=QRectF(-w/2,-h/2,w,h)
            if obj.get('shape')=='round':painter.drawEllipse(r)
            elif obj.get('shape')=='rounded':painter.drawRoundedRect(r,min(w,h)*0.16,min(w,h)*0.16)
            else:painter.drawRect(r)
            painter.setPen(QPen(TEXT,1))
            painter.drawText(r,Qt.AlignmentFlag.AlignCenter,str(obj.get('number','')))
            painter.restore()
        elif typ=='text':
            painter.drawText(pos(obj.get('x',0),obj.get('y',0)),str(obj.get('text','')))

    def paintEvent(self,event):
        q=QPainter(self)
        q.setRenderHint(QPainter.RenderHint.Antialiasing)
        q.fillRect(self.rect(),BG)
        self.paint_grid(q)
        if not self.owner.get('id'):
            q.setPen(QPen(TEXT,1))
            font=q.font();font.setPointSize(15);font.setBold(True);q.setFont(font)
            q.drawText(self.rect(),Qt.AlignmentFlag.AlignCenter,
                       'LibForge CAD\n\n+ New Component     veya     + New Footprint')
        for x in self.shapes:
            selected=x.get('id')==self.selected_id
            delta=self.drag_offset if selected and self.dragging else (0,0)
            self.draw_shape(q,x,delta,selected)
        q.setPen(QPen(HIGHLIGHT,1.6,Qt.PenStyle.DashLine))
        if self.poly_points:
            pts=[self.to_pixel(x) for x in self.poly_points]
            if self.temp_end:pts.append(self.to_pixel(self.temp_end))
            if len(pts)>1:q.drawPolyline(QPolygonF(pts))
            q.setBrush(QBrush(HIGHLIGHT))
            for a in self.poly_points:q.drawEllipse(self.to_pixel(a),3,3)
            q.setBrush(Qt.BrushStyle.NoBrush)
        elif self.first_point and self.temp_end:
            if self.tool=='rect':
                q.drawRect(QRectF(self.to_pixel(self.first_point),self.to_pixel(self.temp_end)).normalized())
            elif self.tool=='circle':
                q.drawEllipse(self.to_pixel(self.first_point),self.dist_px(self.first_point,self.temp_end),self.dist_px(self.first_point,self.temp_end))
            else:q.drawLine(self.to_pixel(self.first_point),self.to_pixel(self.temp_end))
        if self.mouse_snapped and self.tool!='select':
            xy=self.to_pixel(self.mouse_snapped)
            q.setPen(QPen(HIGHLIGHT if self.snap_reason!='Free' else TEXT,1.1))
            q.drawLine(QPointF(xy.x()-9,xy.y()),QPointF(xy.x()+9,xy.y()))
            q.drawLine(QPointF(xy.x(),xy.y()-9),QPointF(xy.x(),xy.y()+9))
            if self.snap_reason in ('Hotspot','Segment'):
                q.drawEllipse(xy,7,7)
        q.end()

    def paint_grid(self,p):
        g=self.grid
        if not g.showGrid or g.style=='hidden':return
        left,right=self.from_pixel(QPointF(0,0))[0],self.from_pixel(QPointF(self.width(),0))[0]
        top,bottom=self.from_pixel(QPointF(0,0))[1],self.from_pixel(QPointF(0,self.height()))[1]
        # Two-level display: fine at close zoom, coarse at distant zoom.
        sx,sy=int(g.visibleX),int(g.visibleY)
        factor=1
        while min(sx,sy)/NM_PER_MM*self.scale*factor<10 and factor<100_000:factor*=g.coarse if g.coarse>1 else 5
        sx*=factor;sy*=factor
        if sx==0 or sy==0:return
        major=max(1,int(g.coarse))
        i0=math.ceil((left-g.originX)/sx);i1=math.floor((right-g.originX)/sx)
        j0=math.ceil((bottom-g.originY)/sy);j1=math.floor((top-g.originY)/sy)
        if i1-i0>1500 or j1-j0>1500:return
        for i in range(i0,i1+1):
            x=self.to_pixel((g.originX+i*sx,0)).x()
            c=GRID_COARSE if i%major==0 else GRID_FINE
            if g.style=='lines':
                p.setPen(QPen(c,1));p.drawLine(QPointF(x,0),QPointF(x,self.height()))
        for j in range(j0,j1+1):
            y=self.to_pixel((0,g.originY+j*sy)).y()
            c=GRID_COARSE if j%major==0 else GRID_FINE
            if g.style=='lines':
                p.setPen(QPen(c,1));p.drawLine(QPointF(0,y),QPointF(self.width(),y))
        if g.style=='dots':
            p.setPen(Qt.PenStyle.NoPen)
            for i in range(i0,i1+1):
                x=self.to_pixel((g.originX+i*sx,0)).x()
                for j in range(j0,j1+1):
                    y=self.to_pixel((0,g.originY+j*sy)).y()
                    major_point=(i%major==0 and j%major==0)
                    p.setBrush(GRID_COARSE if major_point else GRID_FINE)
                    p.drawEllipse(QPointF(x,y),1.5 if major_point else 0.9,1.5 if major_point else 0.9)
        origin=self.to_pixel((g.originX,g.originY))
        p.setPen(QPen(QColor('#9d6653'),1.2))
        p.drawLine(QPointF(origin.x()-12,origin.y()),QPointF(origin.x()+12,origin.y()))
        p.drawLine(QPointF(origin.x(),origin.y()-12),QPointF(origin.x(),origin.y()+12))
