"""Experimental native SchLib/PcbLib exporter via third-party altium-monkey.

Not an Altium-sponsored/verified converter. Atomic staging prevents incomplete
libraries from being mistaken for successful exports. Does not emit .DbLib yet.
"""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from core import NM_PER_MIL, validate_design


def mil(nm: int) -> float:
    return float(nm)/NM_PER_MIL


def safe_path_piece(name:str) -> str:
    """Path-safe component/footprint names, no traversal or separators."""
    import re
    name=re.sub(r'[^A-Za-z0-9_\-\.]+','_',str(name)).strip('._')
    if not name or name in ('.','..'):raise ValueError('Geçersiz kütüphane ismi')
    return name[:100]


def _import_altium():
    try:
        import altium_monkey as m
    except ImportError as e:
        raise ImportError('Native export için `pip install altium-monkey` gerekli.') from e
    return m


def _electrical(m,name):
    key=str(name or 'Passive').strip().upper().replace(' ','_').replace('-','_')
    aliases={'IN':'INPUT','OUT':'OUTPUT','IO':'BIDIRECTIONAL','PASSIVE':'PASSIVE',
             'OPEN_COLLECTOR':'OPEN_COLLECTOR','POWER':'POWER','INPUT':'INPUT','OUTPUT':'OUTPUT'}
    return getattr(m.PinElectrical,aliases.get(key,key),m.PinElectrical.PASSIVE)


def _orient(m, side):
    """LibForge 'side' describes direction from external hotspot INWARD."""
    return {'right':m.Rotation90.DEG_180,'left':m.Rotation90.DEG_0,
            'up':m.Rotation90.DEG_270,'down':m.Rotation90.DEG_90}.get(side,m.Rotation90.DEG_180)


def _symbol(lib,m,record):
    symbol=lib.add_symbol(record['name'])
    symbol.set_description(record.get('description',''))
    n_parts=max([int(o.get('part',1)) for o in record.get('symbol',[])]+[1])
    if n_parts>1:symbol.set_part_count(n_parts)
    for obj in record.get('symbol',[]):
        t=obj.get('type');pid=int(obj.get('part',1))
        if t=='rect':
            symbol.add_rectangle(mil(obj['x']),mil(obj['y']),mil(obj['x']+obj['w']),
                                 mil(obj['y']+obj['h']),is_solid=False,owner_part_id=pid)
        elif t=='polyline':
            points=[(mil(x),mil(y)) for x,y in obj['points']]
            if obj.get('closed'):
                symbol.add_polygon(points,is_solid=False,owner_part_id=pid)
            else:
                symbol.add_polyline(points,owner_part_id=pid)
        elif t=='circle':
            symbol.add_ellipse(mil(obj['x']),mil(obj['y']),mil(obj['radius']),mil(obj['radius']),
                               is_solid=False,owner_part_id=pid)
        elif t=='pin':
            length=int(obj.get('length',5_080_000))
            side=obj.get('side','right')
            sx,sy=int(obj['x']),int(obj['y'])
            dx,dy={'right':(length,0),'left':(-length,0),'up':(0,length),'down':(0,-length)}.get(side,(length,0))
            # make_sch_pin expects the INNER/bodied end and an OUTWARD rotation.
            pin=m.make_sch_pin(designator=str(obj['number']),name=str(obj.get('name','')),
                location_mils=m.SchPointMils.from_mils(mil(sx+dx),mil(sy+dy)),
                orientation=_orient(m,side),length_mils=mil(length),
                electrical_type=_electrical(m,obj.get('electrical')),
                name_font=m.SchFontSpec(name='Arial',size=10),
                designator_font=m.SchFontSpec(name='Arial',size=10))
            pin.owner_part_id=pid
            symbol.add_pin(pin)
        elif t=='text':
            symbol.add_label(str(obj.get('text','')),
                             mil(obj.get('x',0)),mil(obj.get('y',0)),owner_part_id=pid)
        else:
            raise ValueError(f"{record['name']}: desteklenmeyen SchLib nesnesi {t}")
    symbol.add_designator('U?',0,500)
    return symbol


def _footprint(lib,m,record):
    fp=lib.add_footprint(record['name'],description=record.get('description',''))
    for obj in record.get('pcb',[]):
        t=obj.get('type')
        layername=str(obj.get('layer','Top Overlay'))
        layer={'Top Overlay':m.PcbLayer.TOP_OVERLAY,'Top Layer':m.PcbLayer.TOP,
               'Bottom Overlay':m.PcbLayer.BOTTOM_OVERLAY,
               'Bottom Layer':m.PcbLayer.BOTTOM,
               'Multi-Layer':m.PcbLayer.MULTI_LAYER}.get(layername)
        if layer is None:
            if 'Mechanical' in layername:
                num=int(''.join(x for x in layername if x.isdigit()) or '1')
                layer=f'MECHANICAL{num}'
            else:raise ValueError(f"{record['name']}: bilinmeyen PCB katmanı {layername}")
        if t=='pad':
            shape={'rect':m.PadShape.RECTANGLE,'rectangle':m.PadShape.RECTANGLE,
                   'round':m.PadShape.CIRCLE,'circle':m.PadShape.CIRCLE,
                   'rounded':m.PadShape.ROUNDED_RECTANGLE}.get(obj.get('shape','rounded'))
            if shape is None:raise ValueError(f"Bilinmeyen pad şekli: {obj.get('shape')}")
            if layername not in ('Top Layer','Bottom Layer','Multi-Layer'):
                raise ValueError('Pad yalnızca Top/Bottom Layer üzerinde üretiliyor')
            kwargs={}
            if shape==m.PadShape.ROUNDED_RECTANGLE:
                kwargs['corner_radius_percent']=25
            fp.add_pad(designator=str(obj.get('number','')),
                position_mils=(mil(obj['x']),mil(obj['y'])),
                width_mils=mil(obj['w']),height_mils=mil(obj['h']),
                layer=layer,shape=shape,
                rotation_degrees=float(obj.get('rotation',0)),
                hole_size_mils=mil(int(obj.get('hole',obj.get('drill',0)) or 0)),**kwargs)
        elif t=='rect':
            x,y,w,h=(int(obj[k]) for k in ('x','y','w','h'))
            corners=[(x,y),(x+w,y),(x+w,y+h),(x,y+h),(x,y)]
            for a,b in zip(corners,corners[1:]):
                fp.add_track((mil(a[0]),mil(a[1])),(mil(b[0]),mil(b[1])),
                             width_mils=5,layer=layer)
        elif t=='polyline':
            pts=[tuple(x) for x in obj.get('points',[])]
            if obj.get('closed') and len(pts)>2:pts.append(pts[0])
            for a,b in zip(pts,pts[1:]):
                fp.add_track((mil(a[0]),mil(a[1])),(mil(b[0]),mil(b[1])),
                             width_mils=5,layer=layer)
        elif t=='circle':
            fp.add_arc(center_mils=(mil(obj['x']),mil(obj['y'])),
                       radius_mils=mil(obj['radius']),
                       start_angle_degrees=0.0,end_angle_degrees=360.0,
                       width_mils=5,layer=layer)
        else:raise ValueError(f"{record['name']}: bilinmeyen PCB nesnesi {t}")
    return fp


def export_project(project:dict,output_dir:Path) -> str:
    """Create actual native files; only complete on successful save of every file.

    The project's JSON is an editable model, not renamed into .SchLib/.PcbLib.
    """
    m=_import_altium()
    output_dir=Path(output_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    # Fail before writing if any native name clashes or a QA error is present.
    seen=set()
    for section,mode in [('components','sch'),('footprints','pcb')]:
        for rec in project.get(section,[]):
            key=(section,safe_path_piece(rec['name']).casefold())
            if key in seen:raise ValueError(f"Yinelenen kütüphane ismi: {rec['name']}")
            seen.add(key)
            errors=[x for x in validate_design(rec,mode=mode) if x['level']=='error']
            if errors:raise ValueError(f"{rec['name']}: QA hataları: "+' | '.join(x['message'] for x in errors))
    if not project.get('components') and not project.get('footprints'):
        raise ValueError('Önce en az bir komponent veya footprint oluşturun')
    paths=[]
    with tempfile.TemporaryDirectory(prefix='libforge-stage-') as t:
        stage=Path(t)
        for rec in project.get('components',[]):
            cat=Path(*[safe_path_piece(x) for x in rec.get('category','Other').split('/') if x])
            rel=Path('SchLib') / cat / safe_path_piece(rec['name'])
            dest=stage/(str(rel)+'.SchLib');dest.parent.mkdir(parents=True,exist_ok=True)
            lib=m.AltiumSchLib(show_comments_designators=True)
            _symbol(lib,m,rec);lib.save(dest)
            if not dest.is_file() or dest.stat().st_size<512:
                raise RuntimeError(f'Native SchLib üretimi doğrulanamadı: {rec["name"]}')
            paths.append(dest.relative_to(stage))
        for rec in project.get('footprints',[]):
            cat=Path(*[safe_path_piece(x) for x in rec.get('category','Other').split('/') if x])
            rel=Path('PcbLib')/cat/safe_path_piece(rec['name'])
            dest=stage/(str(rel)+'.PcbLib');dest.parent.mkdir(parents=True,exist_ok=True)
            lib=m.AltiumPcbLib()
            _footprint(lib,m,rec);lib.save(dest)
            if not dest.is_file() or dest.stat().st_size<512:
                raise RuntimeError(f'Native PcbLib üretimi doğrulanamadı: {rec["name"]}')
            paths.append(dest.relative_to(stage))
        # Never silently overwrite existing native libraries.
        existing=[p for p in paths if (output_dir/p).exists()]
        if existing:raise FileExistsError('Mevcut dosyalar üzerine yazılmadı: '+', '.join(map(str,existing)))
        for p in paths:
            target=output_dir/p;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(stage/p,target)
    return f'{len(paths)} adet .SchLib/.PcbLib üretildi.\nAltium 26 üzerinde açıp kontrol edin.\nÇıktı: {output_dir}'
