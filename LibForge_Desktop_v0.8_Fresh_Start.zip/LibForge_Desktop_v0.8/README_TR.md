# LibForge CAD Desktop v0.8 — Türkçe kullanım kılavuzu

Bu sürüm **sıfırdan** başlar. Komponent ve footprint listeleri boştur. Eski HTML/JSON kütüphanelerini içe aktarma veya sürüm yükseltme kodu eklenmedi. Sadece yeni LibForge Desktop v0.8 projeleri açılır.

## Sistem gereksinimleri

- Windows 11 ve normal Python 3.12–3.14 kurulumu (64 bit önerilir).
- PySide6 (`python -m pip install -r requirements.txt`).
- **İsteğe bağlı native export:** `python -m pip install -r requirements-native-export.txt`. Bu özellik [altium-monkey](https://github.com/wavenumber-eng/altium_monkey) kütüphanesini kullanır; **AGPL-3.0-or-later** lisansı vardır. Kurum içi/ticari dağıtım veya türetilmiş ürün için lisans sonuçlarını değerlendirin. Üçüncü taraf paket bu ZIP içine dahil edilmemiştir.

## Çalıştırma

`START_WINDOWS.bat` dosyasını çalıştırabilir veya terminalde:

```powershell
py -3 -m pip install -r requirements.txt
py -3 main.py
```

Gerçek `.SchLib` / `.PcbLib` dışa aktarımı için:

```powershell
py -3 -m pip install -r requirements-native-export.txt
```

Uygulama açıkken **File > Export Native**. Komponentlere ayrı `.SchLib`, footprint'lere ayrı `.PcbLib` dosyaları atanmış kategoriler altında üretilir. **Altium Designer'ın açık olması gerekmemesi hedeflenmektedir**, çünkü native dosya yazma motoru kullanılır. Ancak **Altium Designer 26 üzerinde henüz açılış doğrulaması yapılmadı**; çıktıları mutlaka Altium'da kontrol edin. Her CAD nesne türü henüz export kapsamına dahil değildir: desteklenmeyen geometri varsa işlem sessizce eksik dosya üretmek yerine hata verir. `.DbLib` gerçek native export henüz yoktur.

## Yerleşim

- **Sol:** SchLib / Components ve PcbLib / Footprints kategorileri, `+ Category`.
- **Orta:** CAD tuvali. SchLib ve PcbLib pencereleri aynı çizim motorunu kullanır.
- **Sağ:** nesne Properties ve Grid / Snap yöneticisi.
- **Alt:** komponent veritabanı / kalite kontrol.
- **Üst:** çizim araçları (Select, Polyline, Line, Rectangle, Circle, Pin, Pad).

`New Component` yeni sembol oluşturur. Kayıtlı bir footprint mevcutsa oluştururken seçebilirsin; yoksa `(Atanmamış)` kullanıp sonra footprint ekleyebilirsin. `New Footprint` ile yeni PCB çizimi yap. Sol ağacın yapraklarına çift tıklamak ilgili çizimi açar.

## Grid mantığı

- **Şematik varsayılan:** Snap X/Y = 100 mil; Visible X/Y = 100 mil.
- **PCB varsayılan:** Snap X/Y = 0,05 mm; Visible X/Y = 0,5 mm.
- Snap Grid, Visible Grid, origin ve X/Y adımları ayrı ayarlanabilir; elektriksel ve nesne snap seçenekleri bulunur. Mil/mm arasında geçilebilir.
- Geometri tam sayı **nanometre** olarak tutulur. Grid yuvarlaması negatif koordinatlarda da tutarlıdır.
- **Öncelik:** elektriksel pin hotspot'u → nesnenin uç noktası → mevcut çizgi üstündeki nokta → Cartesian grid.
- **Polyline:** her tıklama bir köşe; `Enter`, çift tıklama veya sağ tıklama tamamlar; başlangıç noktasına tıklama kapalı çokgen yapar.
- `G`: snap aralığı hazır değerler arasında değiştirir.
- Mouse wheel: zoom; orta tuş veya Alt+sol tuş: pan; `Delete`: seçili nesneyi sil; `Ctrl+Z / Ctrl+Y`: geri al / ileri al.
- QA sekmesi grid dışı koordinatları, hatalı pad ölçülerini ve tekrarlanan pin/pad numaralarını raporlar.

## Altium ile benzerlik sınırları

Altium'un Cartesian/Visible/Snap ve Electrical Hotspot kavramları temel alınmıştır, ancak **birebir Altium Designer klonu değildir**. PCB'ye özel çoklu yerel grid öncelikleri, polar grid, layer-specific object snap, work guides ve tüm kısayollar bu prototipte henüz yoktur. Şematik ve PCB için ayrı ayarlar saklanır.

## Dosya biçimleri

- `.json` yalnızca **LibForge'un düzenlenebilir çalışma dosyasıdır**, Altium kütüphanesi değildir.
- `.SchLib` ve `.PcbLib` dosyaları için harici Python yazıcı opsiyonel kullanılır.
- PDF/Datasheet otomatik analiz, IPC footprint hesaplaması, gerçek DBLib native çıktısı, 3D STEP gömme ve Altium 26 interoperability testleri henüz tamamlanmadı.

## Test kapsamı

Temel koordinat, grid ve dosya modeli birim testleri `pytest` ile çalıştırıldı. Bulunduğumuz ortamda PySide6 ve `altium-monkey` bağımlılıkları indirilemediği için **grafik arayüz ve gerçek Altium dosya üretimi bu ortamda çalıştırılarak test edilemedi**. Uygulamanın Windows üzerinde çalışması ve native dosyaların Altium'da açılması doğrulanmalıdır.
